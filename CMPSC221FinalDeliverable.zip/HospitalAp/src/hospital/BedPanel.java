package hospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class BedPanel extends JPanel {

    private final BedDAO dao = new BedDAO();
    private DefaultTableModel tableModel;
    private JTable table;

    private JTextField wardField   = new JTextField(15);
    private JTextField bedNumField = new JTextField(15);
    private JTextField idField     = new JTextField(5);

    public BedPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Table ---
        tableModel = new DefaultTableModel(new String[]{"Bed ID", "Ward", "Bed Number"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> populateFormFromSelection());
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- Form panel ---
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Bed Details"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;

        gc.gridx = 0; gc.gridy = 0; form.add(new JLabel("Bed ID (for update/delete):"), gc);
        gc.gridx = 1; form.add(idField, gc);

        gc.gridx = 0; gc.gridy = 1; form.add(new JLabel("Ward:"), gc);
        gc.gridx = 1; form.add(wardField, gc);

        gc.gridx = 0; gc.gridy = 2; form.add(new JLabel("Bed Number:"), gc);
        gc.gridx = 1; form.add(bedNumField, gc);

        // --- Buttons ---
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addBtn    = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn  = new JButton("Clear");
        buttons.add(addBtn); buttons.add(updateBtn);
        buttons.add(deleteBtn); buttons.add(clearBtn);

        gc.gridx = 0; gc.gridy = 3; gc.gridwidth = 2;
        form.add(buttons, gc);

        add(form, BorderLayout.SOUTH);

        // --- Listeners ---
        addBtn.addActionListener(e -> addBed());
        updateBtn.addActionListener(e -> updateBed());
        deleteBtn.addActionListener(e -> deleteBed());
        clearBtn.addActionListener(e -> clearForm());

        refreshTable();
    }

    private void addBed() {
        try {
            String ward = wardField.getText().trim();
            String num  = bedNumField.getText().trim();

            Validator.requireNonEmpty(ward, "Ward");       // Error 1: empty field
            Validator.requireNonEmpty(num,  "Bed Number"); // Error 1: empty field

            dao.insert(ward, num);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Bed added successfully.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void updateBed() {
        try {
            String idStr = idField.getText().trim();
            int id = Validator.requireInteger(idStr, "Bed ID"); // Error 2: type check

            String ward = wardField.getText().trim();
            String num  = bedNumField.getText().trim();
            Validator.requireNonEmpty(ward, "Ward");
            Validator.requireNonEmpty(num,  "Bed Number");

            dao.update(id, ward, num);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Bed updated successfully.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void deleteBed() {
        try {
            String idStr = idField.getText().trim();
            int id = Validator.requireInteger(idStr, "Bed ID");

            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Bed ID " + id + "? This will fail if a patient is assigned to it.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            dao.delete(id);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Bed deleted.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex); // Error 5: FK violation caught here
        }
    }

    private void handleSQLError(SQLException ex) {
        String state = ex.getSQLState();
        String msg;
        if (state != null && state.equals("23503")) {
            // FK violation
            msg = "Foreign Key Error: Cannot delete this bed because a patient is assigned to it.\n"
                + "Remove or reassign the patient first.";
        } else if (state != null && state.startsWith("23")) {
            msg = "Integrity Error: " + ex.getMessage();
        } else {
            msg = "Database Error: " + ex.getMessage();
        }
        JOptionPane.showMessageDialog(this, msg, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        try {
            List<Object[]> rows = dao.getAll();
            for (Object[] row : rows) tableModel.addRow(row);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading beds: " + ex.getMessage());
        }
    }

    private void populateFormFromSelection() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        idField.setText(tableModel.getValueAt(row, 0).toString());
        wardField.setText(tableModel.getValueAt(row, 1).toString());
        bedNumField.setText(tableModel.getValueAt(row, 2).toString());
    }

    private void clearForm() {
        idField.setText(""); wardField.setText(""); bedNumField.setText("");
        table.clearSelection();
    }
}