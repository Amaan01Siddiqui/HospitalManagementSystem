package hospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class AppointmentPanel extends JPanel {

    private final AppointmentDAO dao = new AppointmentDAO();
    private DefaultTableModel tableModel;
    private JTable table;

    private JTextField apptIdField    = new JTextField(5);
    private JTextField patientIdField = new JTextField(10);
    private JTextField doctorField    = new JTextField(20);
    private JTextField dateField      = new JTextField(15);
    private JTextArea  notesArea      = new JTextArea(3, 25);

    public AppointmentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Table ---
        tableModel = new DefaultTableModel(
            new String[]{"Appt ID", "Patient ID", "Doctor", "Date", "Notes"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> populateFormFromSelection());
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- Form ---
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Appointment Details"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;

        gc.gridx = 0; gc.gridy = 0; form.add(new JLabel("Appt ID (update/delete):"), gc);
        gc.gridx = 1; form.add(apptIdField, gc);

        gc.gridx = 0; gc.gridy = 1; form.add(new JLabel("Patient ID:"), gc);
        gc.gridx = 1; form.add(patientIdField, gc);

        gc.gridx = 0; gc.gridy = 2; form.add(new JLabel("Doctor Name:"), gc);
        gc.gridx = 1; form.add(doctorField, gc);

        gc.gridx = 0; gc.gridy = 3; form.add(new JLabel("Date (MM/DD/YYYY):"), gc);
        gc.gridx = 1; form.add(dateField, gc);

        gc.gridx = 0; gc.gridy = 4; form.add(new JLabel("Notes:"), gc);
        notesArea.setLineWrap(true); notesArea.setWrapStyleWord(true);
        gc.gridx = 1; form.add(new JScrollPane(notesArea), gc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addBtn    = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn  = new JButton("Clear");
        buttons.add(addBtn); buttons.add(updateBtn);
        buttons.add(deleteBtn); buttons.add(clearBtn);

        gc.gridx = 0; gc.gridy = 5; gc.gridwidth = 2;
        form.add(buttons, gc);

        add(form, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addAppointment());
        updateBtn.addActionListener(e -> updateAppointment());
        deleteBtn.addActionListener(e -> deleteAppointment());
        clearBtn.addActionListener(e -> clearForm());

        refreshTable();
    }

    private void addAppointment() {
        try {
            String pidStr  = patientIdField.getText().trim();
            String doctor  = doctorField.getText().trim();
            String date    = dateField.getText().trim();
            String notes   = notesArea.getText().trim();

            int patientId = Validator.requireInteger(pidStr, "Patient ID"); // Error 2: type
            Validator.requireNonEmpty(doctor, "Doctor Name");               // Error 1: empty
            Validator.requireNonEmpty(date,   "Date");

            // Date format validation — simple MM/DD/YYYY check
            if (!date.matches("\\d{2}/\\d{2}/\\d{4}")) {
                throw new Validator.ValidationException(
                    "Date '" + date + "' is not valid. Use MM/DD/YYYY format (e.g. 06/25/2026).");
            }

            dao.insert(patientId, doctor, date, notes);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Appointment added successfully.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void updateAppointment() {
        try {
            int apptId    = Validator.requireInteger(apptIdField.getText().trim(),    "Appt ID");
            int patientId = Validator.requireInteger(patientIdField.getText().trim(), "Patient ID");
            String doctor = doctorField.getText().trim();
            String date   = dateField.getText().trim();
            String notes  = notesArea.getText().trim();

            Validator.requireNonEmpty(doctor, "Doctor Name");
            Validator.requireNonEmpty(date,   "Date");

            if (!date.matches("\\d{2}/\\d{2}/\\d{4}")) {
                throw new Validator.ValidationException(
                    "Date '" + date + "' is not valid. Use MM/DD/YYYY format.");
            }

            dao.update(apptId, patientId, doctor, date, notes);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Appointment updated.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void deleteAppointment() {
        try {
            int id = Validator.requireInteger(apptIdField.getText().trim(), "Appt ID");
            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Appointment ID " + id + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            dao.delete(id);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Appointment deleted.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void handleSQLError(SQLException ex) {
        String state = ex.getSQLState();
        String msg;
        if (state != null && state.equals("23503")) {
            msg = "Foreign Key Error: Patient ID does not exist in the database.\n"
                + "Please add the patient first before creating an appointment.";
        } else {
            msg = "Database Error (" + state + "): " + ex.getMessage();
        }
        JOptionPane.showMessageDialog(this, msg, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        try {
            List<Object[]> rows = dao.getAll();
            for (Object[] row : rows) tableModel.addRow(row);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + ex.getMessage());
        }
    }

    private void populateFormFromSelection() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        apptIdField.setText(tableModel.getValueAt(row, 0).toString());
        patientIdField.setText(tableModel.getValueAt(row, 1).toString());
        doctorField.setText(tableModel.getValueAt(row, 2).toString());
        dateField.setText(tableModel.getValueAt(row, 3).toString());
        Object notes = tableModel.getValueAt(row, 4);
        notesArea.setText(notes == null ? "" : notes.toString());
    }

    private void clearForm() {
        apptIdField.setText(""); patientIdField.setText("");
        doctorField.setText(""); dateField.setText(""); notesArea.setText("");
        table.clearSelection();
    }
}