package hospital;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BedDAO {

    public void insert(String ward, String bedNumber) throws SQLException {
        String sql = "INSERT INTO BED (WARD, BED_NUMBER) VALUES (?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, ward);
            ps.setString(2, bedNumber);
            ps.executeUpdate();
        }
    }

    public void update(int bedId, String ward, String bedNumber) throws SQLException {
        String sql = "UPDATE BED SET WARD=?, BED_NUMBER=? WHERE BEDID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, ward);
            ps.setString(2, bedNumber);
            ps.setInt(3, bedId);
            ps.executeUpdate();
        }
    }

    public void delete(int bedId) throws SQLException {
        String sql = "DELETE FROM BED WHERE BEDID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, bedId);
            ps.executeUpdate();
        }
    }

    public List<Object[]> getAll() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT BEDID, WARD, BED_NUMBER FROM BED ORDER BY BEDID";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3)});
            }
        }
        return rows;
    }
}