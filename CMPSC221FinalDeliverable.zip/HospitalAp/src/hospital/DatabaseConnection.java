package hospital;

import java.sql.*;

public class DatabaseConnection {

    private static final String URL = "jdbc:derby:HospitalDB;create=true";
    private static Connection conn = null;

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            conn = DriverManager.getConnection(URL);
        }
        return conn;
    }

    public static void initializeDatabase() {
        try {
            Connection c = getConnection();
            Statement st = c.createStatement();

            // BED table
            try {
                st.execute(
                    "CREATE TABLE BED (" +
                    "  BEDID       INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "  WARD        VARCHAR(50)  NOT NULL," +
                    "  BED_NUMBER  VARCHAR(10)  NOT NULL" +
                    ")"
                );
            } catch (SQLException e) {
                if (!e.getSQLState().equals("X0Y32")) throw e; // table already exists
            }

            // PATIENT table
            try {
                st.execute(
                    "CREATE TABLE PATIENT (" +
                    "  PATIENTID    INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "  FIRST_NAME   VARCHAR(50)  NOT NULL," +
                    "  LAST_NAME    VARCHAR(50)  NOT NULL," +
                    "  EMAIL        VARCHAR(100)," +
                    "  PHONE        VARCHAR(20)," +
                    "  BEDID        INTEGER REFERENCES BED(BEDID)" +
                    ")"
                );
            } catch (SQLException e) {
                if (!e.getSQLState().equals("X0Y32")) throw e;
            }

            // APPOINTMENT table
            try {
                st.execute(
                    "CREATE TABLE APPOINTMENT (" +
                    "  APPOINTMENTID   INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "  PATIENTID       INTEGER NOT NULL REFERENCES PATIENT(PATIENTID)," +
                    "  DOCTOR_NAME     VARCHAR(100) NOT NULL," +
                    "  APPT_DATE       VARCHAR(20)  NOT NULL," +
                    "  NOTES           VARCHAR(500)" +
                    ")"
                );
            } catch (SQLException e) {
                if (!e.getSQLState().equals("X0Y32")) throw e;
            }

            st.close();
        } catch (SQLException e) {
            System.err.println("DB init error: " + e.getMessage());
        }
    }
}