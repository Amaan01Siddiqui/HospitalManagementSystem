package hospital;

public class Validator {

    /** Error 1: Empty field check */
    public static void requireNonEmpty(String value, String fieldName) throws ValidationException {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException("Field '" + fieldName + "' cannot be empty.");
        }
    }

    /** Error 2: Must be a valid integer */
    public static int requireInteger(String value, String fieldName) throws ValidationException {
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            throw new ValidationException("Field '" + fieldName + "' must be a whole number (e.g. 5), not '" + value + "'.");
        }
    }

    /** Error 3: Email format check */
    public static void requireValidEmail(String email) throws ValidationException {
        if (email == null || email.trim().isEmpty()) return; // optional field
        if (!email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[A-Za-z]{2,}$")) {
            throw new ValidationException("Email '" + email + "' is not valid. Expected format: name@domain.com");
        }
    }

    /** Error 4: Phone format check — must be digits/dashes/parens/spaces, 7–15 chars */
    public static void requireValidPhone(String phone) throws ValidationException {
        if (phone == null || phone.trim().isEmpty()) return; // optional field
        if (!phone.matches("^[\\d\\s().+\\-]{7,15}$")) {
            throw new ValidationException("Phone '" + phone + "' is not valid. Expected format: 123-456-7890");
        }
    }

    /** Error 5: Foreign key existence check helper — call before delete to detect FK violation */
    public static void requireNoMessage(String msg) throws ValidationException {
        // placeholder: actual FK errors are caught from SQLException state 23503
    }

    public static class ValidationException extends Exception {
        public ValidationException(String message) {
            super(message);
        }
    }
}