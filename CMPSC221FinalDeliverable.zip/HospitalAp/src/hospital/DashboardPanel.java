package hospital;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * UNIQUE FEATURE: A live bar chart showing number of appointments per doctor.
 * This uses custom JPanel painting (Graphics2D) — a feature not taught in class.
 * The chart refreshes every time the user clicks "Refresh Dashboard".
 */
public class DashboardPanel extends JPanel {

    private final AppointmentDAO dao = new AppointmentDAO();
    private List<Object[]> chartData; // [doctorName, count]
    private ChartCanvas canvas;
    private JLabel statusLabel;

    public DashboardPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Header
        JLabel title = new JLabel("Hospital Dashboard — Appointments per Doctor");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        add(title, BorderLayout.NORTH);

        // Chart canvas
        canvas = new ChartCanvas();
        canvas.setPreferredSize(new Dimension(600, 350));
        canvas.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        add(canvas, BorderLayout.CENTER);

        // Bottom controls
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refreshBtn = new JButton("Refresh Dashboard");
        statusLabel = new JLabel("Click Refresh to load chart.");
        bottom.add(refreshBtn);
        bottom.add(statusLabel);
        add(bottom, BorderLayout.SOUTH);

        refreshBtn.addActionListener(e -> refreshChart());
        refreshChart();
    }

    public void refreshChart() {
        try {
            chartData = dao.getAppointmentsPerDoctor();
            if (chartData.isEmpty()) {
                statusLabel.setText("No appointment data yet.");
            } else {
                statusLabel.setText("Showing " + chartData.size() + " doctor(s).");
            }
            canvas.repaint();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading chart: " + ex.getMessage());
        }
    }

    /** Inner class: paints the bar chart using Graphics2D */
    private class ChartCanvas extends JPanel {
        private final Color[] BAR_COLORS = {
            new Color(70, 130, 180), new Color(60, 179, 113),
            new Color(255, 165, 0),  new Color(220, 80, 80),
            new Color(147, 112, 219)
        };

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (chartData == null || chartData.isEmpty()) {
                g.setColor(Color.GRAY);
                g.setFont(new Font("SansSerif", Font.ITALIC, 14));
                g.drawString("No data to display. Add appointments first.", 40, getHeight() / 2);
                return;
            }

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int margin   = 60;
            int w        = getWidth()  - margin * 2;
            int h        = getHeight() - margin * 2;
            int barCount = chartData.size();
            int barW     = Math.min(80, w / barCount - 20);
            int gap      = (w - barW * barCount) / (barCount + 1);

            // Find max value for scaling
            int maxVal = 1;
            for (Object[] row : chartData) {
                int cnt = (int) row[1];
                if (cnt > maxVal) maxVal = cnt;
            }

            // Draw axes
            g2.setColor(Color.DARK_GRAY);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(margin, margin, margin, margin + h);             // Y axis
            g2.drawLine(margin, margin + h, margin + w, margin + h);    // X axis

            // Y axis labels
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            for (int i = 0; i <= maxVal; i++) {
                int y = margin + h - (int)((double) i / maxVal * h);
                g2.setColor(Color.LIGHT_GRAY);
                g2.drawLine(margin, y, margin + w, y);
                g2.setColor(Color.DARK_GRAY);
                g2.drawString(String.valueOf(i), margin - 22, y + 4);
            }

            // Draw bars
            for (int i = 0; i < barCount; i++) {
                String doctor = (String) chartData.get(i)[0];
                int count     = (int)   chartData.get(i)[1];

                int barH = (int)((double) count / maxVal * h);
                int x    = margin + gap * (i + 1) + barW * i;
                int y    = margin + h - barH;

                // Bar fill
                g2.setColor(BAR_COLORS[i % BAR_COLORS.length]);
                g2.fillRoundRect(x, y, barW, barH, 6, 6);

                // Bar outline
                g2.setColor(BAR_COLORS[i % BAR_COLORS.length].darker());
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(x, y, barW, barH, 6, 6);

                // Count label on top of bar
                g2.setColor(Color.DARK_GRAY);
                g2.setFont(new Font("SansSerif", Font.BOLD, 12));
                String countStr = String.valueOf(count);
                int labelX = x + barW / 2 - g2.getFontMetrics().stringWidth(countStr) / 2;
                g2.drawString(countStr, labelX, y - 4);

                // Doctor name below axis (rotated to fit)
                g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
                String label = doctor.length() > 14 ? doctor.substring(0, 13) + "…" : doctor;
                int nameX = x + barW / 2 - g2.getFontMetrics().stringWidth(label) / 2;
                g2.drawString(label, nameX, margin + h + 16);
            }

            // Chart title
            g2.setColor(Color.DARK_GRAY);
            g2.setFont(new Font("SansSerif", Font.BOLD, 13));
            g2.drawString("Appointments per Doctor", margin, margin - 10);
        }
    }
}