package hospital;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    public void insert(String firstName, String lastName, String email,
                       String phone, Integer bedId) throws SQLException {
        String sql = "INSERT INTO PATIENT (FIRST_NAME, LAST_NAME, EMAIL, PHONE, BEDID) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, email);
            ps.setString(4, phone);
            if (bedId == null) ps.setNull(5, Types.INTEGER);
            else ps.setInt(5, bedId);
            ps.executeUpdate();
        }
    }

    public void update(int patientId, String firstName, String lastName,
                       String email, String phone, Integer bedId) throws SQLException {
        String sql = "UPDATE PATIENT SET FIRST_NAME=?, LAST_NAME=?, EMAIL=?, PHONE=?, BEDID=? WHERE PATIENTID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, email);
            ps.setString(4, phone);
            if (bedId == null) ps.setNull(5, Types.INTEGER);
            else ps.setInt(5, bedId);
            ps.setInt(6, patientId);
            ps.executeUpdate();
        }
    }

    public void delete(int patientId) throws SQLException {
        String sql = "DELETE FROM PATIENT WHERE PATIENTID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ps.executeUpdate();
        }
    }

    public List<Object[]> getAll() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT PATIENTID, FIRST_NAME, LAST_NAME, EMAIL, PHONE, BEDID FROM PATIENT ORDER BY PATIENTID";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Object bedId = rs.getObject(6);
                rows.add(new Object[]{
                    rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5),
                    bedId == null ? "None" : bedId
                });
            }
        }
        return rows;
    }
}