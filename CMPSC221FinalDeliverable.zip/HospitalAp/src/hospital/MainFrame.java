package hospital;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Hospital Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 650);
        setLocationRelativeTo(null);

        // Initialize Derby database and create tables if needed
        DatabaseConnection.initializeDatabase();

        // Tabbed pane — one tab per table + dashboard
        JTabbedPane tabs = new JTabbedPane();

        BedPanel         bedPanel   = new BedPanel();
        PatientPanel     patPanel   = new PatientPanel();
        AppointmentPanel apptPanel  = new AppointmentPanel();
        DashboardPanel   dashboard  = new DashboardPanel();

        tabs.addTab("🛏  Beds",         bedPanel);
        tabs.addTab("🧑  Patients",     patPanel);
        tabs.addTab("📅  Appointments", apptPanel);
        tabs.addTab("📊  Dashboard",    dashboard);

        // Refresh dashboard whenever the user switches to it
        tabs.addChangeListener(e -> {
            int idx = tabs.getSelectedIndex();
            if (idx == 3) dashboard.refreshChart();
        });

        add(tabs);
        setVisible(true);
    }

    public static void main(String[] args) {
        // Use system look and feel for a native appearance
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(MainFrame::new);
    }
}