package hospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class PatientPanel extends JPanel {

    private final PatientDAO dao = new PatientDAO();
    private DefaultTableModel tableModel;
    private JTable table;

    private JTextField idField        = new JTextField(5);
    private JTextField firstNameField = new JTextField(15);
    private JTextField lastNameField  = new JTextField(15);
    private JTextField emailField     = new JTextField(20);
    private JTextField phoneField     = new JTextField(15);
    private JTextField bedIdField     = new JTextField(10);

    public PatientPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Table ---
        tableModel = new DefaultTableModel(
            new String[]{"Patient ID", "First Name", "Last Name", "Email", "Phone", "Bed ID"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> populateFormFromSelection());
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- Form ---
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Patient Details"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.WEST;

        String[] labels = {"Patient ID (update/delete):", "First Name:", "Last Name:",
                           "Email:", "Phone:", "Bed ID (optional):"};
        JTextField[] fields = {idField, firstNameField, lastNameField, emailField, phoneField, bedIdField};

        for (int i = 0; i < labels.length; i++) {
            gc.gridx = 0; gc.gridy = i; form.add(new JLabel(labels[i]), gc);
            gc.gridx = 1; form.add(fields[i], gc);
        }

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addBtn    = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn  = new JButton("Clear");
        buttons.add(addBtn); buttons.add(updateBtn);
        buttons.add(deleteBtn); buttons.add(clearBtn);

        gc.gridx = 0; gc.gridy = labels.length; gc.gridwidth = 2;
        form.add(buttons, gc);

        add(form, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addPatient());
        updateBtn.addActionListener(e -> updatePatient());
        deleteBtn.addActionListener(e -> deletePatient());
        clearBtn.addActionListener(e -> clearForm());

        refreshTable();
    }

    private void addPatient() {
        try {
            String first = firstNameField.getText().trim();
            String last  = lastNameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String bedStr = bedIdField.getText().trim();

            Validator.requireNonEmpty(first, "First Name");  // Error 1: empty
            Validator.requireNonEmpty(last,  "Last Name");
            Validator.requireValidEmail(email);               // Error 3: email format
            Validator.requireValidPhone(phone);               // Error 4: phone format

            Integer bedId = null;
            if (!bedStr.isEmpty()) {
                bedId = Validator.requireInteger(bedStr, "Bed ID"); // Error 2: type
            }

            dao.insert(first, last, email, phone, bedId);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Patient added successfully.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void updatePatient() {
        try {
            int id = Validator.requireInteger(idField.getText().trim(), "Patient ID");
            String first = firstNameField.getText().trim();
            String last  = lastNameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String bedStr = bedIdField.getText().trim();

            Validator.requireNonEmpty(first, "First Name");
            Validator.requireNonEmpty(last,  "Last Name");
            Validator.requireValidEmail(email);
            Validator.requireValidPhone(phone);

            Integer bedId = null;
            if (!bedStr.isEmpty()) {
                bedId = Validator.requireInteger(bedStr, "Bed ID");
            }

            dao.update(id, first, last, email, phone, bedId);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Patient updated successfully.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void deletePatient() {
        try {
            int id = Validator.requireInteger(idField.getText().trim(), "Patient ID");
            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Patient ID " + id + "? This will fail if they have appointments.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            dao.delete(id);
            refreshTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Patient deleted.");
        } catch (Validator.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            handleSQLError(ex);
        }
    }

    private void handleSQLError(SQLException ex) {
        String state = ex.getSQLState();
        String msg;
        if (state != null && state.equals("23503")) {
            msg = "Foreign Key Error: Cannot delete this patient — they have existing appointments.\n"
                + "Delete their appointments first.";
        } else if (state != null && state.equals("23000")) {
            msg = "Duplicate Key Error: A record with this ID already exists.";
        } else {
            msg = "Database Error (" + state + "): " + ex.getMessage();
        }
        JOptionPane.showMessageDialog(this, msg, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        try {
            List<Object[]> rows = dao.getAll();
            for (Object[] row : rows) tableModel.addRow(row);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + ex.getMessage());
        }
    }

    private void populateFormFromSelection() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        idField.setText(tableModel.getValueAt(row, 0).toString());
        firstNameField.setText(tableModel.getValueAt(row, 1).toString());
        lastNameField.setText(tableModel.getValueAt(row, 2).toString());
        emailField.setText(nullSafe(tableModel.getValueAt(row, 3)));
        phoneField.setText(nullSafe(tableModel.getValueAt(row, 4)));
        Object bedVal = tableModel.getValueAt(row, 5);
        bedIdField.setText(bedVal == null || bedVal.toString().equals("None") ? "" : bedVal.toString());
    }

    private String nullSafe(Object o) { return o == null ? "" : o.toString(); }

    private void clearForm() {
        idField.setText(""); firstNameField.setText(""); lastNameField.setText("");
        emailField.setText(""); phoneField.setText(""); bedIdField.setText("");
        table.clearSelection();
    }
}