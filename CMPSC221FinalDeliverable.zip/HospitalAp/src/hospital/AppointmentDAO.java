package hospital;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    public void insert(int patientId, String doctorName, String apptDate, String notes) throws SQLException {
        String sql = "INSERT INTO APPOINTMENT (PATIENTID, DOCTOR_NAME, APPT_DATE, NOTES) VALUES (?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ps.setString(2, doctorName);
            ps.setString(3, apptDate);
            ps.setString(4, notes);
            ps.executeUpdate();
        }
    }

    public void update(int apptId, int patientId, String doctorName, String apptDate, String notes) throws SQLException {
        String sql = "UPDATE APPOINTMENT SET PATIENTID=?, DOCTOR_NAME=?, APPT_DATE=?, NOTES=? WHERE APPOINTMENTID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ps.setString(2, doctorName);
            ps.setString(3, apptDate);
            ps.setString(4, notes);
            ps.setInt(5, apptId);
            ps.executeUpdate();
        }
    }

    public void delete(int apptId) throws SQLException {
        String sql = "DELETE FROM APPOINTMENT WHERE APPOINTMENTID=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, apptId);
            ps.executeUpdate();
        }
    }

    public List<Object[]> getAll() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT APPOINTMENTID, PATIENTID, DOCTOR_NAME, APPT_DATE, NOTES FROM APPOINTMENT ORDER BY APPOINTMENTID";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(new Object[]{
                    rs.getInt(1), rs.getInt(2), rs.getString(3),
                    rs.getString(4), rs.getString(5)
                });
            }
        }
        return rows;
    }

    public List<Object[]> getAppointmentsPerDoctor() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT DOCTOR_NAME, COUNT(*) AS CNT FROM APPOINTMENT GROUP BY DOCTOR_NAME ORDER BY CNT DESC";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(new Object[]{rs.getString(1), rs.getInt(2)});
            }
        }
        return rows;
    }
}